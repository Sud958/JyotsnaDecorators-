
# Jyotsna Decorators - React + Vite Starter

**Project created for Sudipta / Jyotsna Decorators**

## Quick start

1. Install Node.js (v18+ recommended)
2. Extract the project folder
3. In project root run:
```bash
npm install
npm run dev
```

4. Open your browser at the address shown (usually http://localhost:5173)

## Notes
- This project uses Vite + React + TailwindCSS + Framer Motion.
- Images in the template are hotlinked from Unsplash. Replace with your own photos in `src/assets` if desired.
