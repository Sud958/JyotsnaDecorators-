import React from 'react'
import { motion } from 'framer-motion'
import { Phone, Mail, MapPin, ChevronRight } from 'lucide-react'

export default function App(){
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-100 text-gray-800">
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-indigo-600">Jyotsna Decorators</h1>
          <nav className="space-x-6">
            <a href="#services" className="hover:text-indigo-600 font-medium">Services</a>
            <a href="#about" className="hover:text-indigo-600 font-medium">About</a>
            <a href="#contact" className="hover:text-indigo-600 font-medium">Contact</a>
          </nav>
        </div>
      </header>

      <section className="flex flex-col md:flex-row items-center justify-between max-w-7xl mx-auto px-6 py-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="md:w-1/2">
          <h2 className="text-4xl md:text-5xl font-extrabold text-indigo-700 mb-4">
            Elegant Decor & Exquisite Catering
          </h2>
          <p className="text-lg text-gray-600 mb-6">
            Jyotsna Decorators brings beauty, class, and taste to every occasion — from weddings to corporate events, with stunning decoration and premium catering services.
          </p>
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-2xl inline-flex items-center">
            Explore Services <ChevronRight className="ml-2" size={18} />
          </button>
        </motion.div>

        <motion.img initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1 }} src="https://images.unsplash.com/photo-1604014237800-1c28b4b41e76?auto=format&fit=crop&w=1000&q=80" alt="Event Decoration" className="rounded-2xl shadow-lg mt-10 md:mt-0 md:w-1/2" />
      </section>

      <section id="services" className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h3 className="text-3xl font-bold text-indigo-700 mb-12">Our Services</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="shadow-lg rounded-2xl p-6">
              <img src="https://images.unsplash.com/photo-1555255707-c07966088b7b?auto=format&fit=crop&w=800&q=80" alt="Wedding Decoration" className="rounded-xl mb-4" />
              <h4 className="text-xl font-semibold mb-2">Wedding Decoration</h4>
              <p className="text-gray-600">Luxurious themes, floral setups, and elegant designs for your special day.</p>
            </div>

            <div className="shadow-lg rounded-2xl p-6">
              <img src="https://images.unsplash.com/photo-1573497019360-5c31a7e4e5b1?auto=format&fit=crop&w=800&q=80" alt="Event Catering" className="rounded-xl mb-4" />
              <h4 className="text-xl font-semibold mb-2">Catering Services</h4>
              <p className="text-gray-600">Delicious multi-cuisine menu with professional catering staff and hygiene.</p>
            </div>

            <div className="shadow-lg rounded-2xl p-6">
              <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=800&q=80" alt="Corporate Events" className="rounded-xl mb-4" />
              <h4 className="text-xl font-semibold mb-2">Corporate Events</h4>
              <p className="text-gray-600">Stylish decor and food arrangements tailored for professional gatherings.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="py-20 bg-gradient-to-r from-indigo-50 to-blue-100">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <h3 className="text-3xl font-bold text-indigo-700 mb-6">About Us</h3>
          <p className="text-lg text-gray-700 leading-relaxed">
            Jyotsna Decorators is a trusted name in Dhanbad for over a decade, providing exceptional decoration and catering services for weddings, receptions, and corporate events. Our team is passionate about turning every occasion into a memory of beauty, flavor, and joy.
          </p>
        </div>
      </section>

      <section id="contact" className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <h3 className="text-3xl font-bold text-indigo-700 mb-8">Contact Us</h3>
          <div className="space-y-4 text-lg">
            <p className="flex items-center justify-center"><Phone className="mr-2 text-indigo-600" /> <b>9031082049</b></p>
            <p className="flex items-center justify-center"><Mail className="mr-2 text-indigo-600" /> jyotshnadecorators@gmail.com</p>
            <p className="flex items-center justify-center"><MapPin className="mr-2 text-indigo-600" /> Dhanbad, Jharkhand, India</p>
          </div>
        </div>
      </section>

      <footer className="bg-indigo-700 text-white text-center py-6 mt-10">
        <p>© {new Date().getFullYear()} Jyotsna Decorators | All Rights Reserved</p>
      </footer>
    </div>
  )
}
